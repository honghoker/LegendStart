package com.example.myfragment1.MSMain;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.myfragment1.R;

public class settingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ms_activity_setting);
    }
}

# Android Swipe Controller Demo

![](https://cdn-images-1.medium.com/max/800/1*5slEuen7TiIF3rkV4AmaPA.gif)

This is source code from the article about creating swipe menu with RecyclerView without any external libraries.

https://medium.com/@fanfatal/android-swipe-menu-with-recyclerview-8f28a235ff28

